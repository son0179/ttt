T = int(input())
for _ in range(T):
	n = int(input())
	a = int(0)
	b = int(0)
	c = int(0)
	d = int(0)
	e = int(0)
	a += int(n/60)
	n %= 60
	if n>35:
		a += 1
		c = 6-int((n+5)/10)
		n %= 10
		if n>=5:
			e += 10-n
		else:
			d += n
	else:
		b = int((n+4)/10)
		n %= 10
		if n>=6:
			e += 10-n
		else:
			d += n
	print(a,b,c,d,e)