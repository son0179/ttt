import java.io.*;
import java.util.*;
 
public class Main {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for(int i=0; i<T; i++){
            int n = sc.nextInt();
            int a,b,c,d,e;
            a = b = c = d = e = 0;
            a += n/60;
            n%=60;
            if(n>35){
                a++;
                c = 6-(n+5)/10;
                n %= 10;
                if(n>=5){
                    e += 10-n;
                }
                else{
                    d += n;
                }
            }
            else{
                b = (n+4)/10;
                n %= 10;
                if(n>=6){
                    e += 10-n;
                }
                else{
                    d += n;
                }
            }
            System.out.print(a+" "+b+" "+c+" "+d+" "+e+"\n");
        }
    }
}