import java.util.*;

public class Main {	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k = sc.nextInt();
        int ans = 0;
        
        n -= k * (k + 1) / 2;

        if(n < 0) ans = -1;
        else if(n % k == 0) ans = k - 1;
        else ans = k;
        
		System.out.println(ans);
	}
}

